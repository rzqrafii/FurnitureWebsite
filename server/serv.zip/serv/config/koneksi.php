<?php
    class db
    {
        public $server = "localhost";
        public $username = "id4133903_furniturelc";
        public $password = "rafii123";
        public $database = "id4133903_furniture";
        public $host_data = "rafiirizqullah23.000webhostapp.com";
    }
?>